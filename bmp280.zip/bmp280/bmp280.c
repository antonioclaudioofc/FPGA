/*
* =============================================
* Projeto: Leitura de Temperatura e Pressão com BMP280
* =============================================
*
* ✅ Objetivo:
* Ler temperatura (°C) e pressão (hPa) a partir do sensor BMP280 via I2C.
*
* ✅ Recursos utilizados:
* - Placa BitDogLab (RP2040)
* - Sensor BMP280 com I2C (endereço 0x76)
* - GPIO2 (SDA) e GPIO3 (SCL) para comunicação
*
* ✅ Aplicações:
* - Monitoramento climático
* - Estações meteorológicas embarcadas
* - Sensores ambientais em IoT
*
* ✅ Informações sobre o Sensor BMP280
* - Comunicação: I2C
* - Endereço I2C padrão: 0x76 ou 0x77 (dependendo do pino SDO)
* - Mede: Temperatura (°C) e Pressão (Pa ou hPa)
* - Requer leitura de coeficientes de calibração
*
* ✅ Conexões sugeridas para BitDogLab
* - Sinal BMP280 BitDogLab GPIO sugerido
* - VCC 3.3V 3.3V
* - GND GND GND
* - SDA I2C Data GPIO 2
* - SCL I2C Clk GPIO 3
* - Utilizar o conector I2C 1 da BitDogLab
*
* ✅ Observações
* - A temperatura e a pressão são compensadas com os coeficientes internos, conforme descrito no
datasheet.
* - Saídas:
* - Temperatura em graus Celsius (com duas casas decimais)
* - Pressão atmosférica em hPa (hectopascal)
*/
#include <stdio.h>        // Biblioteca padrão para entrada e saída
#include "pico/stdlib.h"  // Biblioteca do SDK para funções básicas do RP2040
#include "hardware/i2c.h" // Biblioteca para uso do barramento I2C
#include <math.h>         // Biblioteca matemática (usada para cálculos de precisão, se necessário)
// Definições dos pinos e endereço do sensor
#define BMP280_ADDR 0x76 // Endereço I2C padrão do BMP280
#define I2C_SDA_PIN 2    // Pino GPIO 2 como SDA
#define I2C_SCL_PIN 3    // Pino GPIO 3 como SCL
// Variáveis globais para coeficientes de calibração do BMP280
uint16_t dig_T1;
int16_t dig_T2, dig_T3;
uint16_t dig_P1;
int16_t dig_P2, dig_P3, dig_P4, dig_P5, dig_P6, dig_P7, dig_P8, dig_P9;
int32_t t_fine; // Valor intermediário usado nas compensações
// Função para escrever um valor em um registrador do BMP280 via I2C
void bmp_write(uint8_t reg, uint8_t val)
{
    uint8_t buf[2] = {reg, val};                          // Cria um buffer com o registrador e o valor
    i2c_write_blocking(i2c1, BMP280_ADDR, buf, 2, false); // Envia via I2C para o sensor
}
// Função para ler múltiplos bytes de um registrador do BMP280
void bmp_read(uint8_t reg, uint8_t *buf, uint8_t len)
{
    i2c_write_blocking(i2c1, BMP280_ADDR, &reg, 1, true);  // Envia o endereço do registrador
    i2c_read_blocking(i2c1, BMP280_ADDR, buf, len, false); // Lê os dados na sequência
}
// Lê dois bytes e retorna um valor de 16 bits sem sinal
uint16_t read_u16(uint8_t reg)
{
    uint8_t buf[2];
    bmp_read(reg, buf, 2);         // Lê dois bytes do registrador
    return (buf[1] << 8) | buf[0]; // Combina os bytes (little endian)
}
// Lê dois bytes e interpreta como valor com sinal
int16_t read_s16(uint8_t reg)
{
    return (int16_t)read_u16(reg); // Converte o valor lido para int16_t
}
// Lê os coeficientes de calibração do sensor BMP280
void bmp280_read_calibration()
{
    dig_T1 = read_u16(0x88);
    dig_T2 = read_s16(0x8A);
    dig_T3 = read_s16(0x8C);
    dig_P1 = read_u16(0x8E);
    dig_P2 = read_s16(0x90);
    dig_P3 = read_s16(0x92);
    dig_P4 = read_s16(0x94);
    dig_P5 = read_s16(0x96);
    dig_P6 = read_s16(0x98);
    dig_P7 = read_s16(0x9A);
    dig_P8 = read_s16(0x9C);
    dig_P9 = read_s16(0x9E);
}
// Inicializa o sensor BMP280 (configura e lê calibração)
void bmp280_init()
{
    bmp_write(0xF4, 0x27);     // ctrl_meas: oversampling x1, modo normal
    bmp_write(0xF5, 0xA0);     // config: tempo de espera 1000ms, filtro off
    bmp280_read_calibration(); // Lê os coeficientes de calibração
}
// Realiza a compensação da temperatura (em centésimos de °C)
int32_t bmp280_compensate_T(int32_t adc_T)
{
    int32_t var1 = ((((adc_T >> 3) - ((int32_t)dig_T1 << 1))) * ((int32_t)dig_T2)) >> 11;
    int32_t var2 = (((((adc_T >> 4) - ((int32_t)dig_T1)) *
                      ((adc_T >> 4) - ((int32_t)dig_T1))) >>
                     12) *
                    ((int32_t)dig_T3)) >>
                   14;
    t_fine = var1 + var2;           // Valor auxiliar para compensar pressão depois
    return (t_fine * 5 + 128) >> 8; // Retorna temperatura em centésimos de grau Celsius
}
// Realiza a compensação da pressão e retorna valor em Pa
uint32_t bmp280_compensate_P(int32_t adc_P)
{
    int64_t var1 = ((int64_t)t_fine) - 128000;
    int64_t var2 = var1 * var1 * (int64_t)dig_P6;
    var2 = var2 + ((var1 * (int64_t)dig_P5) << 17);
    var2 = var2 + (((int64_t)dig_P4) << 35);
    var1 = ((var1 * var1 * (int64_t)dig_P3) >> 8) +
           ((var1 * (int64_t)dig_P2) << 12);
    var1 = (((((int64_t)1) << 47) + var1)) * ((int64_t)dig_P1) >> 33;
    if (var1 == 0)
        return 0; // Protege contra divisão por zero
    int64_t p = 1048576 - adc_P;
    p = (((p << 31) - var2) * 3125) / var1;
    var1 = (((int64_t)dig_P9) * (p >> 13) * (p >> 13)) >> 25;
    var2 = (((int64_t)dig_P8) * p) >> 19;
    p = ((p + var1 + var2) >> 8) + (((int64_t)dig_P7) << 4);
    return (uint32_t)(p >> 8); // Converte de Pa para hPa (divide por 100)
}
// Função principal
int main()
{
    stdio_init_all(); // Inicializa as interfaces padrão de entrada/saída
    // Inicializa a comunicação I2C na porta i2c1, com 100kHz
    i2c_init(i2c1, 100 * 1000);
    gpio_set_function(I2C_SDA_PIN, GPIO_FUNC_I2C); // Configura SDA
    gpio_set_function(I2C_SCL_PIN, GPIO_FUNC_I2C); // Configura SCL
    gpio_pull_up(I2C_SDA_PIN);                     // Puxa SDA para nível alto
    gpio_pull_up(I2C_SCL_PIN);                     // Puxa SCL para nível alto
    sleep_ms(1000);                                // Aguarda 1 segundo
    printf("Iniciando BMP280...\n");
    bmp280_init(); // Inicializa o sensor
    while (true)
    {
        uint8_t data[6];
        bmp_read(0xF7, data, 6);                                           // Lê 6 bytes: 3 para pressão e 3 para temperatura
        int32_t adc_P = (data[0] << 12) | (data[1] << 4) | (data[2] >> 4); // Pressão bruta
        int32_t adc_T = (data[3] << 12) | (data[4] << 4) | (data[5] >> 4); // Temperatura bruta
        int32_t temp = bmp280_compensate_T(adc_T);                         // Temperatura compensada
        uint32_t press = bmp280_compensate_P(adc_P);                       // Pressão compensada
        // Imprime os valores convertidos para °C e hPa
        printf("Temperatura: %.2f °C | Pressão: %.2f hPa\n", temp / 100.0, press / 100.0);
        sleep_ms(2000); // Aguarda 2 segundos antes da próxima leitura
    }
}