/*
*
===============================================================
* Projeto: Leitura de Batimentos Cardíacos e Oxigenação com MAX30100
*
===============================================================
*
* Objetivo:
* Ler sinais de batimentos cardíacos (HR) e saturação de oxigênio no sangue (SpO2)
* utilizando o sensor óptico MAX30100 via I2C.
*
* Recursos utilizados:
* - Placa BitDogLab (RP2040)
* - Sensor MAX30100 (I2C, endereço padrão 0x57)
* - GPIO2 (SDA) e GPIO3 (SCL) para comunicação
*
* Aplicações:
* - Monitoramento de frequência cardíaca
* - Medição de oxigenação no sangue (SpO2)
* - Wearables e projetos de saúde embarcados
*
* Informações sobre o Sensor MAX30100
* - Comunicação: I2C
* - Endereço I2C padrão: 0x57
* - Mede: Frequência cardíaca (HR) e Saturação de oxigênio (SpO2)
* - Sensores ópticos: LED vermelho (660nm) e infravermelho (940nm)
* - Necessita calibração e filtragem de sinal para leituras estáveis
*
* Conexões sugeridas para BitDogLab
* - Sinal MAX30100 BitDogLab GPIO sugerido
* - VCC 3.3V 3.3V
* - GND GND GND
* - SDA I2C Data GPIO 2
* - SCL I2C Clk GPIO 3
* - Utilizar o conector I2C 1 da BitDogLab
*
* Observações
* - O sensor deve ser ativado com escrita nos registradores de configuração.
* - A leitura dos dados ocorre nos registradores FIFO (dados IR e RED).
* - Filtros de média e algoritmos de detecção de pico são necessários para extrair HR e SpO2.
* - Pode haver necessidade de ajustar corrente dos LEDs e modo de operação (modo SpO2, modo HR,
etc).
*/
/*
Descrição:
Este código realiza a leitura dos batimentos cardíacos (BPM) e da
saturação de oxigênio no sangue (SpO₂) utilizando o sensor MAX30102
conectado via I2C ao Raspberry Pi Pico W. O sensor emite luzes IR e
vermelha alternadamente, e um fotodiodo interno mede a quantidade de
luz refletida pelo tecido (tipicamente o dedo). A diferença de absorção
entre os dois comprimentos de onda permite calcular BPM e estimar SpO₂.
Funcionamento:
- LED IR é usado para detectar picos de pulso (cálculo do BPM)
- LEDs RED e IR são usados para estimar a saturação de oxigênio (SpO₂)
- Os sinais são suavizados com média móvel
25
- Os cálculos são feitos a cada amostra
- Os valores são exibidos via terminal serial
Conexões (I2C):
- SDA = GPIO 2
- SCL = GPIO 3
- Sensor MAX30102 alimentado com 3.3V
Observação:
O LED vermelho pisca em alta frequência e pode não ser visível a olho nu.
O sensor está funcionando mesmo que a luz não seja vista.
*/
#include <stdio.h>
#include <math.h>
#include "pico/stdlib.h"
#include "hardware/i2c.h"
// Endereço I2C padrão do MAX30102
#define MAX30102_ADDRESS 0x57
// Porta e pinos I2C usados no Pico W
#define I2C_PORT i2c1
#define SDA_PIN 2
#define SCL_PIN 3
// Número de amostras para média móvel
#define MEDIA_MOVEL_N 10
// Buffers circulares para armazenar amostras IR e RED
uint32_t ir_buffer[MEDIA_MOVEL_N] = {0};
uint32_t red_buffer[MEDIA_MOVEL_N] = {0};
int media_index = 0;
// Variáveis para controle de detecção de pico e BPM
absolute_time_t ultimo_pico;
bool pico_detectado = false;
float bpm = 0.0;
float spo2 = 0.0;
// Função para escrever em um registrador do MAX30102
void max30102_write(uint8_t reg, uint8_t value)
{
    uint8_t buffer[2] = {reg, value};
    i2c_write_blocking(I2C_PORT, MAX30102_ADDRESS, buffer, 2, false);
}
// Função para ler os valores do FIFO (RED e IR)
bool max30102_read_fifo(uint32_t *ir, uint32_t *red)
{
    uint8_t reg = 0x07; // Registrador FIFO_DATA
    uint8_t data[6];
    i2c_write_blocking(I2C_PORT, MAX30102_ADDRESS, &reg, 1, true);
    int res = i2c_read_blocking(I2C_PORT, MAX30102_ADDRESS, data, 6, false);
    if (res != 6)
        return false;
    // Cada leitura são 3 bytes: RED e depois IR
    *red = ((uint32_t)data[0] << 16) | ((uint32_t)data[1] << 8) | data[2];
    *ir = ((uint32_t)data[3] << 16) | ((uint32_t)data[4] << 8) | data[5];
    return true;
}
// Inicializa o sensor MAX30102 no modo SPO2 (LED vermelho e IR)
void max30102_init()
{
    max30102_write(0x02, 0x00); // FIFO_WR_PTR
    max30102_write(0x03, 0x00); // OVF_COUNTER
    max30102_write(0x04, 0x00); // FIFO_RD_PTR
    max30102_write(0x09, 0x02); // Modo SPO2 (ativa RED e IR)
    max30102_write(0x0A, 0x1F); // SPO2 config: sample rate e pulse width
    max30102_write(0x0C, 0x1F); // LED1 (IR) intensidade
    max30102_write(0x0D, 0xFF); // LED2 (RED) intensidade máxima
}
// Calcula a média de um buffer de inteiros
float calcular_media(uint32_t *buffer, int tamanho)
{
    uint64_t soma = 0;
    for (int i = 0; i < tamanho; i++)
        soma += buffer[i];
    return (float)soma / tamanho;
}
// Estima SpO2 com base na razão de absorção dos sinais RED e IR
float calcular_spo2(uint32_t ir_ac, uint32_t ir_dc, uint32_t red_ac, uint32_t red_dc)
{
    if (ir_dc == 0 || red_dc == 0)
        return 0;
    float R = ((float)red_ac / red_dc) / ((float)ir_ac / ir_dc);
    float spo2 = 110.0 - 25.0 * R;
    if (spo2 > 100.0)
        spo2 = 100.0;
    if (spo2 < 0.0)
        spo2 = 0.0;
    return spo2;
}
// Função principal
int main()
{
    stdio_init_all();               // Inicializa saída serial via USB
    i2c_init(I2C_PORT, 400 * 1000); // Inicializa I2C a 400 kHz
    gpio_set_function(SDA_PIN, GPIO_FUNC_I2C);
    gpio_set_function(SCL_PIN, GPIO_FUNC_I2C);
    gpio_pull_up(SDA_PIN);
    gpio_pull_up(SCL_PIN);
    max30102_init(); // Inicializa o sensor
    sleep_ms(1000);  // Tempo para estabilização
    printf("Sensor MAX30102 iniciado.\n");
    while (true)
    {
        uint32_t ir, red;
        // Leitura dos dados do FIFO do sensor
        if (max30102_read_fifo(&ir, &red))
        {
            // Armazena as novas leituras nos buffers circulares
            ir_buffer[media_index] = ir;
            red_buffer[media_index] = red;
            media_index = (media_index + 1) % MEDIA_MOVEL_N;
            // Calcula médias (DC) e variações (AC)
            float ir_media = calcular_media(ir_buffer, MEDIA_MOVEL_N);
            float red_media = calcular_media(red_buffer, MEDIA_MOVEL_N);
            float ir_ac = fabsf(ir - ir_media);
            float red_ac = fabsf(red - red_media);
            // Detecção de pico para BPM
            bool acima = ir > ir_media * 1.01;
            if (acima && !pico_detectado)
            {
                pico_detectado = true;
                absolute_time_t agora = get_absolute_time();
                int64_t intervalo_us = absolute_time_diff_us(ultimo_pico, agora);
                if (intervalo_us > 100000)
                { // Ignora picos muito próximos (<100ms)
                    bpm = 60.0 * 1000000 / intervalo_us;
                    ultimo_pico = agora;
                }
            }
            else if (!acima)
            {
                pico_detectado = false;
            }
            // Estima o valor de SpO2 com base na razão de absorção
            spo2 = calcular_spo2((uint32_t)ir_ac, (uint32_t)ir_media,
                                 (uint32_t)red_ac, (uint32_t)red_media);
            // Exibe os resultados
            printf("IR=%lu | RED=%lu | BPM=%.1f | SpO2=%.1f%%\n", ir, red, bpm, spo2);
        }
        sleep_ms(100); // Taxa de amostragem de ~10 Hz
    }
    return 0;
}